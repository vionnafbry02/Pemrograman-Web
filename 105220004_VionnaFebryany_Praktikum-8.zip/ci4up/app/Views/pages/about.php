<?= $this->extend('layout/template'); ?>

    <?= $this->section('content'); ?>
        <div class="container">
            <div class="row">
                <div class="col">

                    <h1>About</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum, nisi enim! Vitae molestiae
                        iusto
                        doloribus
                        similique, ducimus explicabo magni dolorem quos atque itaque voluptates, ut eveniet dolore
                        dignissimos illo
                        sit!
                    </p>
                </div>
            </div>
        </div>
        <?= $this->endSection(); ?>